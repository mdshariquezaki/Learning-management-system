export interface Member {
    id: string,
    email: string,
    familyName: string,
    givenName: string,
    picture: string,
}
