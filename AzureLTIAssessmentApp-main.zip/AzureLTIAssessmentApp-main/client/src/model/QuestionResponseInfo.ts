export interface QuestionResponseInfo {
    chosenOption: number,
}