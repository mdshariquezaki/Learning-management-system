export enum StudentResponseStatus {
    NotStarted = "Not started",
    InProgress = "In progress",
    Complete = "Complete",
}
