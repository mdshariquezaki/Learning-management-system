export interface StudentQuestion {
    id: string,
    name: string,
    description: string,
    options: string[],
    chosenOption: number,
    textType:string, 
}
