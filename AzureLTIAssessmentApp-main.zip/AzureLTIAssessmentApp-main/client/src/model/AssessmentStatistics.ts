import {StudentResult} from "./StudentResult";

export interface AssessmentStatistics {
    studentResponses: StudentResult[],
}