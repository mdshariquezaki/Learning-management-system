export enum AssessmentStatus {
    InitialSetup = "Initial setup",
    Draft = "Draft",
    Published = "Published",
    Ongoing = "Ongoing",
    Complete = "Complete",
}
