﻿namespace Assessment.App.Database.Model
{
    public class QuestionResponseInfo
    {
        public int ChosenOption { get; set; }
    }
}