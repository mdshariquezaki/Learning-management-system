﻿using System.Collections.Generic;

namespace Assessment.App.Functions.Teacher.Dto
{
    public class DeleteQuestionsRequest
    {
        public List<string> QuestionIds { get; set; }
    }
}