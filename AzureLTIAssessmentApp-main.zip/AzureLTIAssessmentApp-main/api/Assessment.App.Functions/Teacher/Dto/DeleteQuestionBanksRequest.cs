﻿using System.Collections.Generic;

namespace Assessment.App.Functions.Teacher.Dto
{
    public class DeleteQuestionBanksRequest
    {
        public List<string> QuestionBankIds { get; set; }
    }
}