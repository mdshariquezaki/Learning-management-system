﻿namespace Assessment.App.Functions.Teacher.Dto
{
    public class CreateQuestionBankResponse
    {
        public string Id { get; set; }
    }
}