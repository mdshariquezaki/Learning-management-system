﻿namespace Assessment.App.Functions.Teacher.Dto
{
    public class CreateQuestionResponse
    {
        public string Id { get; set; }
    }
}